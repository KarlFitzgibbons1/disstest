package graphColouring;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

public class Console {
	private static LinkedList<Vertex> verInit;
	private Vertex vertex;
	private static Graph graph;
	private LinkedList<Vertex> deg;
	

	

	public static void main(String[] args) throws IOException {
		graph=buildGraph();
		
		int no=getChromaticSLF(graph);
		System.out.println(no);
		
		
		
		
		
		
		
		
		
	}
	public static Graph buildGraph() {	
		File file = new File("M:\\Data\\testdata.csv");
		int i = 0;
		int p = 0;
		Graph out = null;
		LinkedList<Vertex> nodes = null;
		
		try {
			// Create a new scanner class that will read the file
			Scanner scanner = new Scanner(file);

			// while the file has lines to read
			while (scanner.hasNextLine()) {

				String lines = scanner.nextLine();
				// for first row separated headers to use for vertex ID, allowing for creation
				// of vertex objects
				if (i == 0) {
					LinkedList<Vertex> verts=new LinkedList();
					String[] items = lines.split(",");
					for (int j = 1; j < items.length; j++) {
						Vertex temp = new Vertex(Integer.parseInt(items[j]), verInit, 0, 0);	
					
						verts.add(temp);
						nodes=verts;
					}
						Graph g= new Graph(nodes);
						i++;
						out=g;
					}

				 else {
					//split comma for CSV
					String[] items = lines.split(",");
					for (int j = 0; j < items.length; j++) {
						for (Vertex currentVertex : nodes) {
							if (currentVertex.getId() == Integer.parseInt(items[j])) {
								if (Integer.parseInt(items[j])==1) {
									currentVertex.addNeighbour(out.getVertex(j));
									currentVertex.addDegree();
									}
								if (currentVertex.getId() ==1) {
									if (p==0){						
										currentVertex.minusDegree();
										p++;
										}
									
								}
	
							}
								
						}
						

					}

				}
			}
			// catch the exception if no file can be found
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return out;

	}

	public static int getChromaticSLF(Graph g) {
		LinkedList<Vertex> sat;
		Vertex use = null;
		
		for (int i = 0; i <= g.length(); i++) {
			int colour=0;
			
			// first we get the vertex in order of saturation
			sat = g.getMaxSaturation();

			// for loop to select vertex from highest saturation that has the highest degree
			// to deal with ties
			for (Vertex currentVertex : sat) {
				int d = 0;
				if (currentVertex.getDegree() > d) {
					d = currentVertex.getDegree();
					use = currentVertex;
				}
			}
			for (int j = 0; j < g.length(); j++) {
				LinkedList<Vertex> neighbours = new LinkedList();
				for (Vertex currentVertex : neighbours) {
					if (use.getColour() == currentVertex.getColour()) {
						colour++;
					}

				}

			}
			use.setColour(colour);
		}
		return graph.getChroNo();
		
		
		
		
	}
}


