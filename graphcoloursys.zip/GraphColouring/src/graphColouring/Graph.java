package graphColouring;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

public class Graph {
	LinkedList<Vertex> vertex;

	String text;
	private Vertex vert;

	public Graph(LinkedList<Vertex> vertex) {
		this.vertex = vertex;
	}

	public Vertex getVertex(int id) {
		for (Vertex currentVertex : this.vertex) {
			if (currentVertex.getId() == id) {
				return currentVertex;
			}
		}
		return null;
	}

	public void addVertex(Vertex vertex) {
		this.vertex.add(vertex);
	}

	public void getDegreeList() {
		for (Vertex currentVertex : vertex) {
			int degree = currentVertex.getDegree();
		}
	}

	public int length() {
		return vertex.size();
	}

	public LinkedList<Vertex> getVertexList() {
		return this.vertex;
	}

	public LinkedList<Vertex> getMaxDegree() {
		int deg = 0;
		LinkedList<Vertex> max = new LinkedList();

		for (Vertex currentVertex : vertex) {
			if (currentVertex.getDegree() > deg) {
				deg = currentVertex.getDegree();
			}
		}
		for (Vertex currentVertex : vertex) {
			if (currentVertex.getDegree() == deg) {
				max.add(currentVertex);

			}
		}

		return max;

	}

	public LinkedList<Vertex> getMaxSaturation() {

		int sat = 0;
		LinkedList<Vertex> max = new LinkedList();
		for (Vertex currentVertex : vertex) {

			if (currentVertex.getColour() == 0) {

				if (currentVertex.getSaturation(currentVertex.getId()) > sat) {
					sat = currentVertex.getSaturation(currentVertex.getId());
				}
			}
		}

		for (Vertex currentVertex : vertex) {

			if (currentVertex.getColour() == 0) {

				if (currentVertex.getSaturation(currentVertex.getId()) == sat) {
					max.add(currentVertex);
				}
			}
		}
		return max;

	}

	public int getChroNo(){
		int cN=0;
		for(Vertex currentVertex: vertex) {
			if(currentVertex.getColour()>cN) {
				cN=currentVertex.getColour();
			}
			
		}
		return cN;
		
		
	}
}

