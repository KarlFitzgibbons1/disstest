package graphColouring;

import java.util.LinkedList;

public class Vertex {
	int id;
	int colour;
	int degree;
	LinkedList<Vertex> adjacent;

	public Vertex(int id, LinkedList<Vertex> adjacent, int colour, int degree) {
		this.id = id;
		this.colour = colour;
		this.adjacent = adjacent;
		this.degree = degree;
	}

	public int getId() {
		return this.id;
	}

	public int getColour() {
		return this.colour;

	}

	public int getDegree() {
		return this.degree;
	}

	public void addDegree() {
		this.degree = this.degree + 1;
	}

	public void minusDegree() {
		this.degree = this.degree - 1;

	}

	public void addNeighbour(Vertex neighbour) {
		adjacent.add(neighbour);
	}

	public void setColour(int colour) {
		this.colour = colour;

	}

	public LinkedList<Vertex> getNeighbours(int id) {
		LinkedList<Vertex> v= new LinkedList();
		
		for (Vertex currentVertex : adjacent) {
			if (currentVertex.getId() == id) {
				v.add(currentVertex);
			}
		}
		return null;

	}

	public int getSaturation(int id) {
		
		int sat = 0;
		for (Vertex currentVertex : adjacent) {
			if (currentVertex.getColour() > 0) {
				sat = sat + 1;
			}

		}
		return sat;

	}
		
}


